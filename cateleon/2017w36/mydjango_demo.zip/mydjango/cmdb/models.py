from django.db import models

# Create your models here.

# 继承一个类，创建2个字段，类型是 char，最长16字节；
class UserInfo(models.Model):
    user = models.CharField(max_length=16)
    pwd = models.CharField(max_length=16)
