#!/usr/bin/python
# encoding:utf-8

"""
@author: yuanxin
contact:
@file: 2017/9/1-urllib_getHtml.py
@time: 2017/9/1 
"""
import re
import urllib.request

def getHtml(url):
    page = urllib.request.urlopen(url)
    html = page.read()
    return html

def getImg(html):
    reg = r'src="(.+?\.jpg)" pic_ext'
    imgre = re.compile(reg)
    print(imgre)
    html = html.decode('utf-8')
    print(html)
    imglist = re.findall(imgre, html)
    # print(imglist)
    # x = 0
    # for imgurl in imglist:
    #     urllib.request.urlretrieve(imgurl, "%s.jsp" %x)
    #     x = x+1

html = getHtml("http://tieba.baidu.com/p/2460150866")
print(getImg(html))