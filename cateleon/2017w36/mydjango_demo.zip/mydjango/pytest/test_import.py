#!/usr/bin/python
# encoding:utf-8

"""
@author: yuanxin
contact:
@file: 2017/8/31-test_import.py
@time: 2017/8/31 
"""

from main_a import a
